﻿namespace WebApplication1.Models
{
    public class BookingModel
    {
        public string? StartDate { get; set; }

        public string? EndDate { get; set; }
        
        public string?   Details { get; set; }

        public string? SubTotal { get; set; }

        public string? BookingFee { get; set; }

        public string? VatAmount { get; set; }
        public string? TotalAmount { get; set; }

        public BookingModel()
        {
            // Parameterless constructor
        }

        public BookingModel(string startDate, string endDate, string details, string subTotal, string bookingFee, string vatAmount, string totalAmount)
        {
            StartDate = startDate;
            EndDate = endDate;
            Details = details;
            SubTotal = subTotal;
            BookingFee = bookingFee;
            VatAmount = vatAmount;
            TotalAmount = totalAmount;  
        }
    }
}
