﻿namespace WebApplication1.Models
{
    public class Car
    {

        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public string? Title { get; set; }
        public string? ImageUrl { get; set; }

        public string? Status { get; set; }
        public decimal PricePerDay { get; set; }
        public Car() { }


        public Car( string name,string description,string title, string imageurl, string status, decimal priceperday) { 
            Name = name;
            Description = description;
            Title = title;
            ImageUrl = imageurl;
            Status = status;
            PricePerDay = priceperday;
             
        }


    }
}