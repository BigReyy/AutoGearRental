﻿namespace WebApplication1.Models
{
    public class IncidentModel
    {
        public string? Title { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }

        public string? FullName { get; set; }
        public string? Email { get; set; }
        public string? Phone { get; set; }
        public DateTime DateOfAccident { get; set; }
        public string? LocationOfAccident { get; set; }
        public string?   Details { get; set; }

        public IncidentModel()
        {
            // Parameterless constructor
        }

        public IncidentModel(string title, string firstname,  string fullName, string email, string phone, DateTime dateOfAccident, string locationOfAccident, string details)
        {
            Title = title;
            FirstName = firstname;
            FullName = fullName;
            Email = email;
            Phone = phone;
            DateOfAccident = dateOfAccident;
            LocationOfAccident = locationOfAccident;
            Details = details;
        }
    }
}
