﻿using System.Data.SqlClient;

namespace WebApplication1.Models
{
    public class UserDetails
    {
        public string? Email { get; set; }
        public string? Id { get; set; }

        public UserDetails()
        {
            // Parameterless constructor
        }

        public UserDetails(string email, string id)
        {
            Email = email;
            Id = id;
        }

      /*  public static UserDetails GetUserDetailsFromDatabase(string userId)
        {
            string connectionString = "your_connection_string"; // Replace with your actual connection string
            string query = "SELECT Email, Id FROM Users WHERE Id = @UserId";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserId", userId);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string email = reader.GetString(reader.GetOrdinal("Email"));
                            string id = reader.GetString(reader.GetOrdinal("Id"));

                            return new UserDetails(email, id);
                        }
                    }
                }
            }

            return null;
        }*/
    }
}
