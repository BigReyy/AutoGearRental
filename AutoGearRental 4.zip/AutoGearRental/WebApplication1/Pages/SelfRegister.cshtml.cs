﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MySql.Data.MySqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Data.Common;
using System.Diagnostics;

namespace WebApplication1.Pages
{
    public class SelfRegisterModel : PageModel
    {
        private readonly ILogger<SelfRegisterModel> _logger;
        private readonly IConfiguration _configuration;

        [BindProperty]
        public string? Email { get; set; }

        [BindProperty]
        public string? Password { get; set; }

        [BindProperty]
        public string? FirstName { get; set; }

        [BindProperty]
        public string? LastName { get; set; }

        [BindProperty]
        public string? PhoneNumber { get; set; }

        public SelfRegisterModel(ILogger<SelfRegisterModel> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
        }

        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            if (string.IsNullOrEmpty(FirstName) || string.IsNullOrEmpty(LastName) || string.IsNullOrEmpty(Password) || string.IsNullOrEmpty(PhoneNumber))
            {
                return BadRequest("All fields are required.");
            }

            string connectionString = _configuration.GetConnectionString("carrentalsdatabase");

            if (string.IsNullOrEmpty(connectionString))
            {
                return BadRequest("Connection string is not configured.");
            }

            try
            {
                InsertRegistrationData(connectionString);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while inserting registration data.");
                return BadRequest("An error occurred during self registration. Please try again later.");
            }

            return RedirectToPage("LoginSelfRegister");
        }


        private void InsertRegistrationData(string connectionString)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string tableExistsQuery = @"SELECT COUNT(*) FROM information_schema.tables WHERE table_name = 'selfregistration'";
                using (MySqlCommand command = new MySqlCommand(tableExistsQuery, connection))
                {
                    bool tableExists = Convert.ToInt32(command.ExecuteScalar()) > 0;

                    if (!tableExists)
                    {
                        string createTableQuery = @"CREATE TABLE selfregistration (
                                        Id INT AUTO_INCREMENT PRIMARY KEY,
                                        Email NVARCHAR(255) NOT NULL,
                                        FirstName NVARCHAR(255) NOT NULL,
                                        LastName NVARCHAR(255) NOT NULL,
                                        Password NVARCHAR(255) NOT NULL,
                                        PhoneNumber NVARCHAR(20) NOT NULL
                                    )";
                        using (MySqlCommand createTableCommand = new MySqlCommand(createTableQuery, connection))
                        {
                            createTableCommand.ExecuteNonQuery();
                        }
                    }
                }

                string insertDataQuery = @"INSERT INTO selfregistration (Email, FirstName, LastName, Password, PhoneNumber)
                               VALUES (@Email, @FirstName, @LastName, @Password, @PhoneNumber)";
                using (MySqlCommand command = new MySqlCommand(insertDataQuery, connection))
                {
                    command.Parameters.AddWithValue("@Email", Email);
                    command.Parameters.AddWithValue("@FirstName", FirstName);
                    command.Parameters.AddWithValue("@LastName", LastName);
                    command.Parameters.AddWithValue("@Password", Password); // Make sure to encrypt password before inserting
                    command.Parameters.AddWithValue("@PhoneNumber", PhoneNumber);

                    command.ExecuteNonQuery();
                }

                connection.Close();
            }
        }
    }
}
