﻿using Microsoft.AspNetCore.Mvc; // Importing the namespace for MVC-related functionality
using Microsoft.AspNetCore.Mvc.RazorPages; // Importing the namespace for Razor Pages
using MySql.Data.MySqlClient; // Importing the namespace for MySQL database connectivity
using Microsoft.Extensions.Configuration; // Importing the namespace for accessing application configuration
using Microsoft.Extensions.Logging; // Importing the namespace for logging functionality
using System; // Importing the namespace for fundamental .NET types
using System.Data.Common; // Importing the namespace for ADO.NET database operations
using WebApplication1.Models; // Importing the namespace for application models
using System.Text;
using System.Security.Cryptography;
using System.Diagnostics;

namespace WebApplication1.Pages // Defining the namespace for Razor Pages
{
    public class LoginModel : PageModel // Defining the LoginModel class as a Razor Page model
    {
        private readonly ILogger<LoginModel> _logger; // Declaring a logger field for logging
        private readonly IConfiguration _configuration; // Declaring a configuration field for accessing application settings

        [BindProperty]
        public string? Email { get; set; } // Declaring a property for storing user email input

        [BindProperty]
        public string? Password { get; set; } // Declaring a property for storing user password input

        public LoginModel(ILogger<LoginModel> logger, IConfiguration configuration)
        {
            _logger = logger; // Initializing the logger field with the provided logger instance
            _configuration = configuration; // Initializing the configuration field with the provided configuration instance
        }

        public void OnGet()
        {
            // Method executed when the page is requested via HTTP GET
        }

        public IActionResult OnPost(string email, string password)
        {
            string decryptedPassword = decryptPassword(password);
            string? connectionString = _configuration.GetConnectionString("carrentalsdatabase"); // Retrieving the connection string from the application configuration

            if (string.IsNullOrEmpty(connectionString))
            {
                return BadRequest("Connection string is not configured."); // Returning a BadRequest response if the connection string is not configured
            }

            string query = "SELECT Email, Password, Id FROM registration WHERE Email = @Email AND Password = @Password"; // Defining the SQL query to retrieve user details
            string? storedEmail = null; // Initializing a variable to store the retrieved email
            string? storedPassword = null; // Initializing a variable to store the retrieved password
            int storedId; // Declaring a variable to store the retrieved user ID

            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open(); // Opening a connection to the MySQL database

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Email", email); // Adding a parameter for the email to the SQL command
                        command.Parameters.AddWithValue("@Password", decryptedPassword); // Adding a parameter for the password to the SQL command

                        using (MySqlDataReader reader = command.ExecuteReader()) // Executing the SQL command and retrieving a data reader
                        {
                            if (reader.Read()) // Checking if data was successfully retrieved
                            {
                                storedEmail = reader.GetString(reader.GetOrdinal("Email")); // Retrieving the email from the data reader
                                storedPassword = reader.GetString(reader.GetOrdinal("Password"));
                                // Retrieving the password from the data reader
                                storedId = reader.GetInt32(reader.GetOrdinal("Id")); // Retrieving the user ID from the data reader

                                var userDetails = new UserDetails(storedEmail, storedId.ToString()); // Creating a UserDetails object with the retrieved email and ID
                                ViewData["UserDetails"] = userDetails; // Storing the UserDetails object in the ViewData dictionary
                            }
                            else
                            {
                                return BadRequest("Database Error."); // Returning a BadRequest response if the email or password is invalid
                            }


                        }

                        Debug.WriteLine($"enail : {storedEmail}");
                        Debug.WriteLine($"storedPassword : {storedPassword}");
                        Debug.WriteLine($"storedId : {storedId}");
                    }
                }

                if (IsCredentialsValid(email, decryptedPassword, storedEmail, storedPassword)) // Checking if the entered credentials are valid
                {
                    return RedirectToPage("/MainPages/Home"); // Redirecting to the home page if the credentials are valid
                }
                else
                {
                    return BadRequest("Invalid email or password."); // Returning a BadRequest response if the email or password is invalid
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while processing the login."); // Logging an error if an exception occurs
                return StatusCode(500, "An error occurred while processing the login."); // Returning a StatusCode 500 response for internal server error
            }
        }

        private static bool IsCredentialsValid(string enteredEmail, string enteredPassword, string storedEmail, string storedPassword)
        {
            return enteredEmail == storedEmail && enteredPassword == storedPassword; // Checking if the entered credentials match the stored credentials
        }
        // Hash a string using SHA-256 algorithm
        private static string ComputeHash(string input)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(input));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in hashBytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private string decryptPassword(string input){
            
            string encryptedPassword = ComputeHash(input);
            Debug.WriteLine($"decrypted Password: {encryptedPassword}");
            return encryptedPassword;
}
    }
}
