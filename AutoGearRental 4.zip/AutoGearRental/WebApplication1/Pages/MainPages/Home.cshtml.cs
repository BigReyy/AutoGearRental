﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebApplication1.Models;

namespace WebApplication1.Pages.MainPages
{
    public class HomeModel : PageModel
    {
        public UserDetails? UserDetails { get; set; }
        private readonly ILogger<HomeModel> _logger;

        public HomeModel(ILogger<HomeModel> logger)
        {
            _logger = logger;
        }

        public void OnGet(UserDetails? userDetails = null)
        {
            if (userDetails != null)
            {
                // Access userDetails.Email and userDetails.Id here
                UserDetails = userDetails;
            }
        }
    }
}
