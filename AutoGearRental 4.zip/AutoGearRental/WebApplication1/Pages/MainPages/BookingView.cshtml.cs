﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebApplication1.Models;

namespace WebApplication1.Pages.MainPages
{
    public class BookingViewModel : PageModel
    {
        public BookingModel? BookingDetails { get; set; }
        private readonly ILogger<BookingViewModel> _logger;

        public BookingViewModel(ILogger<BookingViewModel> logger)
        {
            _logger = logger;
        }

        public void OnGet(BookingModel? bookingDetails)
        {
            if (bookingDetails != null)
            {
                BookingDetails = bookingDetails;
            }
        }
    }
}
