﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Globalization;
using System.Reflection;
using WebApplication1.Models;

namespace WebApplication1.Pages.MainPages
{
    public class LogAnAccidentModel : PageModel
    {
        private readonly ILogger<LogAnAccidentModel> _logger;
        private readonly IConfiguration _configuration;

        [BindProperty]
        public string? Title { get; set; }

        [BindProperty]
        public string? Email { get; set; }

        [BindProperty]
        public string? FirstName { get; set; }

        [BindProperty]
        public string? LastName { get; set; }

        [BindProperty]
        public string? IncidentDetails { get; set; }

        [BindProperty]
        public DateTime IncidentDate { get; set; }

        [BindProperty]
        public DateTime IncidentTime { get; set; }

        [BindProperty]
        public string? IncidentLocation { get; set; }

        // Add this property to your RegisterModel class
        [BindProperty]
        public string? ParsedIncidentDate { get; set; }

        [BindProperty]
        public IncidentModel? Incident { get; set; }
        public UserDetails? UserDetails { get; set; }

        public LogAnAccidentModel(ILogger<LogAnAccidentModel> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
        }

        public void OnGet()
        {
            // Assign the formatted date string to the ParsedDateOfBirth property
            ParsedIncidentDate = IncidentDate.ToString("dd-MM-yyyy");
            UserDetails = ViewData["UserDetails"] as UserDetails;
        }

        public IActionResult OnPost()
        {
            if (string.IsNullOrEmpty(FirstName))
            {
                return BadRequest("First name is required.");
            }

            string? connectionString = _configuration.GetConnectionString("carrentalsdatabase");

            if (string.IsNullOrEmpty(connectionString))
            {
                return BadRequest("Connection string is not configured.");
            }

            try
            {
                // Assign the values to the IncidentModel
                Incident!.Email = Email;
                Incident.FirstName = FirstName;
                Incident.LastName = LastName;
                Incident.FullName = $"{Title} {FirstName} {LastName}";
                Incident.Details = IncidentDetails;
                Incident.DateOfAccident = IncidentDate;
                Incident.LocationOfAccident = IncidentLocation;
                InsertIncidentData(connectionString);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while inserting registration data.");
                return BadRequest("An error occurred during registration.");
            }

            return RedirectToPage("IncidentView", Incident);
        }

        private void InsertIncidentData(string connectionString)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Check if the table exists
                string tableExistsQuery = @"SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Incidents'";
                using (SqlCommand command = new(tableExistsQuery, connection))
                {
                    bool tableExists = command.ExecuteScalar() != null;

                    // Create the "registration" table if it doesn't exist
                    if (!tableExists)
                    {
                        string createTableQuery = @"CREATE TABLE Incidents (
                                        Id INT IDENTITY(1,1) PRIMARY KEY,
                                        Email NVARCHAR(255) NOT NULL,
                                        FirstName NVARCHAR(255) NOT NULL,
                                        LastName NVARCHAR(255) NOT NULL,
                                        IncidentTime TIME NOT NULL,
                                        IncidentDate DATE NOT NULL,
                                        IncidentLocation NVARCHAR(255) NOT NULL,
                                        IncidentDetails NVARCHAR(255) NOT NULL
                                    )";
                        using (SqlCommand createTableCommand = new SqlCommand(createTableQuery, connection))
                        {
                            createTableCommand.ExecuteNonQuery();
                        }
                    }
                }

                // Validate the DateOfBirth value and convert it to the desired format
                string dateOfBirthString = IncidentDate.ToString("dd-MM-yyyy");
                DateTime parsedDateOfBirth;
                if (!DateTime.TryParseExact(dateOfBirthString, "dd-MM-yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out parsedDateOfBirth))
                {
                    throw new Exception("Invalid DateOfBirth value. Please provide a valid date in the format dd-MM-yyyy.");
                }

                if (parsedDateOfBirth < SqlDateTime.MinValue.Value)
                {
                    throw new Exception("DateOfIncident value is earlier than the minimum supported date.");
                }

                // Insert the registration data into the "registration" table
                string insertDataQuery = @"INSERT INTO Incidents (Email, FirstName, LastName, IncidentTime, IncidentDate, IncidentLocation, IncidentDetails)
                               VALUES (@Email, @FirstName, @LastName, @IncidentTime, @IncidentDate, @IncidentLocation, @IncidentDetails)";
                using (SqlCommand command = new SqlCommand(insertDataQuery, connection))
                {
                    command.Parameters.AddWithValue("@Email", Email);
                    command.Parameters.AddWithValue("@FirstName", FirstName);
                    command.Parameters.AddWithValue("@LastName", LastName);
                    command.Parameters.AddWithValue("@IncidentTime", IncidentTime);
                    command.Parameters.AddWithValue("@IncidentDate", IncidentDate);
                    command.Parameters.AddWithValue("@IncidentLocation", IncidentLocation);
                    command.Parameters.AddWithValue("@IncidentDetails", IncidentDetails);
                    command.ExecuteNonQuery();
                }

                connection.Close();
            }
        }
    }
}
