﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebApplication1.Models;

namespace WebApplication1.Pages.MainPages
{
    public class IncidentViewModel : PageModel
    {
        public IncidentModel? IncidentDetails { get; set; }
        private readonly ILogger<IncidentViewModel> _logger;

        public IncidentViewModel(ILogger<IncidentViewModel> logger)
        {
            _logger = logger;
        }

        public void OnGet(IncidentModel? incidentDetails = null)
        {
            if (incidentDetails != null)
            {
                IncidentDetails = incidentDetails;
            }
        }
    }
}
