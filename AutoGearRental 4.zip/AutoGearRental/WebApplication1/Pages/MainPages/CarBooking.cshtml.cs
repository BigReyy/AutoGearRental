﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using WebApplication1.Models;
using MySql.Data.MySqlClient;


using System.Diagnostics;


namespace WebApplication1.Pages.MainPages
{
    public class CarBookingModel : PageModel
    {
        private readonly ILogger<CarBookingModel> _logger;
        private readonly IConfiguration _configuration;

        public CarBookingModel(ILogger<CarBookingModel> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
        }

        [BindProperty]
        public int CarId { get; set; }

        [BindProperty]
        public string? StartDate { get; set; }

        [BindProperty]
        public string? EndDate { get; set; }

        public List<Car>? Cars { get; set; }

        [TempData]
        public string? Subtotal { get; set; }

        [TempData]
        public string? BookingFee { get; set; }

        [TempData]
        public string? VatAmount { get; set; }

        [TempData]
        public string? TotalAmount { get; set; }

        public BookingModel Booking { get; set; }

        public void OnGet(int carId)
        {
            Cars = GetAvailableCars();
            CarId = carId;
        }

        public IActionResult OnPost()
        {
            decimal dailyPrice = GetDailyPrice(CarId);
            int numberOfDays = (int)(DateTime.Parse(EndDate!) - DateTime.Parse(StartDate!)).TotalDays;
            decimal subtotal = dailyPrice * numberOfDays;
            decimal bookingFee = 25;
            decimal vatRate = 0.2m;
            decimal vatAmount = subtotal * vatRate;
            decimal totalAmount = subtotal + bookingFee + vatAmount;

            Subtotal = subtotal.ToString("0.00");
            BookingFee = bookingFee.ToString("0.00");
            VatAmount = vatAmount.ToString("0.00");
            TotalAmount = totalAmount.ToString("0.00");

            Booking = new BookingModel
            {
                StartDate = StartDate,
                EndDate = EndDate,
                BookingFee = BookingFee,
                VatAmount = VatAmount,
                TotalAmount = TotalAmount,
                Details = "Details",
                SubTotal = Subtotal
            };

            return RedirectToPage("BookingView", Booking);
        }

        private List<Car> GetAvailableCars()
        {
            List<Car> cars = new List<Car>();

            string? connectionString = _configuration.GetConnectionString("carrentalsdatabase");

            if (string.IsNullOrEmpty(connectionString))
            {
                // Return an empty list or display an error message
                return cars;
            }
            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM Cars WHERE StockLevel > 0";
                    MySqlCommand command = new MySqlCommand(query, connection);

                    MySqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        int carType = reader.GetInt32(reader.GetOrdinal("CarType"));
                        int stockLevel = reader.GetInt32(reader.GetOrdinal("StockLevel"));
                        string carImages = reader.GetString(reader.GetOrdinal("Images"));
                        string name = GetCarName(carType);
                        decimal pricePerDay = GetDailyPrice(carType);
                        string description = GetCarDescription(carType);
                        string status = GetCarStatus(stockLevel);
                        //Debug.WriteLine($"{carImages}Errrrorrr");
                        cars.Add(new Car { Id = carType, Name = name, PricePerDay = pricePerDay, Description = description, ImageUrl = carImages, Status = status });

                        foreach (var car in cars){
                            Debug.WriteLine($"{car.Name}{car.ImageUrl}");
                        }
                    }

                    reader.Close();
                }
            }
            catch(Exception e) {
                Debug.WriteLine("Errrrorrr" + e);
    
                    }

            return cars;
        }

        private decimal GetDailyPrice(int carType)
        {
            decimal dailyPrice = 0;

            switch (carType)
            {
                case 1: // City car
                    dailyPrice = 25;
                    break;
                case 2: // Hatchback
                    dailyPrice = 35;
                    break;
                case 3: // Standard saloon
                    dailyPrice = 45;
                    break;
                case 4: // Premium
                    dailyPrice = 85;
                    break;
                default:
                    // Handle invalid car types
                    break;
            }

            return dailyPrice;
        }

        private string GetCarName(int carType)
        {
            string carName = "";

            switch (carType)
            {
                case 1:
                    carName = "City Car";
                    break;
                case 2:
                    carName = "Hatchback";
                    break;
                case 3:
                    carName = "Standard Saloon";
                    break;
                case 4:
                    carName = "Premium";
                    break;
                default:
                    return "Invalid car type";
            }

            return carName;
        }

        private string GetCarStatus(int stockLevel)
        {
            if (stockLevel > 0)
            {
                return "In Stock";
            }
            else
            {
                return "Not In Stock";
            }
        }

        private string GetCarDescription(int carType)
        {
            string description = "";

            switch (carType)
            {
                case 1: // City car
                    description = "Compact and efficient car, perfect for urban driving.";
                    break;
                case 2: // Hatchback
                    description = "Versatile and practical car with a spacious trunk.";
                    break;
                case 3: // Standard saloon
                    description = "Comfortable and stylish car, ideal for everyday use.";
                    break;
                case 4: // Premium
                    description = "Luxurious and high-performance car for an exceptional driving experience.";
                    break;
                default:
                    description = "Unknown car type.";
                    break;
            }

            return description;
        }
    }
}
