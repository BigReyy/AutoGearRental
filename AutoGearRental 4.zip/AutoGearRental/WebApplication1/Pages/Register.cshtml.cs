﻿using System;
using System.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using MySql.Data.MySqlClient;
using System.Globalization;
using System.Security.Cryptography;
using System.Diagnostics;
using System.Text;

namespace WebApplication1.Pages
{
    public class RegisterModel : PageModel
    {
        private readonly ILogger<RegisterModel> _logger;
        private readonly IConfiguration _configuration;

        [BindProperty]
        public string Email { get; set; }

        [BindProperty]
        public string FirstName { get; set; }

        [BindProperty]
        public string LastName { get; set; }

        [BindProperty]
        public string Password { get; set; }
       
        [BindProperty]
        public DateTime DateOfBirth { get; set; }

        [BindProperty]
        public string Gender { get; set; }

        [BindProperty]
        public string ParsedDateOfBirth { get; set; }

        public RegisterModel(ILogger<RegisterModel> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
        }

        public void OnGet()
        {
            ParsedDateOfBirth = DateOfBirth.ToString("dd-MM-yyyy");
        }



        public IActionResult OnPost()
        {
            if (string.IsNullOrEmpty(FirstName) || string.IsNullOrEmpty(LastName) || string.IsNullOrEmpty(Password) || DateOfBirth == DateTime.MinValue)
            {
                return BadRequest("All fields are required.");
            }

          
            string? connectionString = _configuration.GetConnectionString("carrentalsdatabase");
            //InsertCars(connectionString ?? "Invalid databese connectionstring");
            if (string.IsNullOrEmpty(connectionString))
            {
                return BadRequest("Connection string is not configured.");
            }

            try
            {
               InsertRegistrationData(connectionString);
             // InsertCars(connectionString);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while inserting registration data.");
                return BadRequest("An error occurred during registration. Please try again later.");
            }

            return RedirectToPage("Login");
        }

        private void InsertRegistrationData(string connectionString)
        {
            string DataPassworfd = encryptPassword(Password);
            Debug.WriteLine($"Encrypted Password :{DataPassworfd}");

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string tableExistsQuery = @"SELECT COUNT(*) FROM information_schema.tables WHERE table_name = 'registration'";
                using (MySqlCommand command = new MySqlCommand(tableExistsQuery, connection))
                {
                    bool tableExists = Convert.ToInt32(command.ExecuteScalar()) > 0;

                    if (!tableExists)
                    {
                        string createTableQuery = @"CREATE TABLE registration (
                                        Id INT AUTO_INCREMENT PRIMARY KEY,
                                        Email NVARCHAR(255) NOT NULL,
                                        FirstName NVARCHAR(255) NOT NULL,
                                        LastName NVARCHAR(255) NOT NULL,
                                        Password NVARCHAR(255) NOT NULL,
                                        DateOfBirth DATE NOT NULL,
                                        Gender NVARCHAR(10) NOT NULL
                                    )";
                        using (MySqlCommand createTableCommand = new MySqlCommand(createTableQuery, connection))
                        {
                            createTableCommand.ExecuteNonQuery();
                        }
                    }
                }

                string dateOfBirthString = DateOfBirth.ToString("yyyy-MM-dd"); // MySQL date format
                DateTime parsedDateOfBirth;
                if (!DateTime.TryParseExact(dateOfBirthString, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out parsedDateOfBirth))
                {
                    throw new Exception("Invalid DateOfBirth value. Please provide a valid date in the format dd-MM-yyyy.");
                }

                if (parsedDateOfBirth < System.Data.SqlTypes.SqlDateTime.MinValue.Value)
                {
                    throw new Exception("DateOfBirth value is earlier than the minimum supported date.");
                }

                string insertDataQuery = @"INSERT INTO registration (Email, FirstName, LastName, Password, DateOfBirth, Gender)
                               VALUES (@Email, @FirstName, @LastName, @Password, @DateOfBirth, @Gender)";
                using (MySqlCommand command = new MySqlCommand(insertDataQuery, connection))
                {
                    command.Parameters.AddWithValue("@Email", Email);
                    command.Parameters.AddWithValue("@FirstName", FirstName);
                    command.Parameters.AddWithValue("@LastName", LastName);
                    command.Parameters.AddWithValue("@Password", DataPassworfd);
                    command.Parameters.AddWithValue("@DateOfBirth", dateOfBirthString); // MySQL date format
                    command.Parameters.AddWithValue("@Gender", Gender);

                    command.ExecuteNonQuery();
                }

                connection.Close();
            }
        }










        //Encryption functions

        // Hash a string using SHA-256 algorithm
        private static string ComputeHash(string input)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(input));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in hashBytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private string encryptPassword(string input)
        {

            string encryptedPassword = ComputeHash(input);
            Debug.WriteLine($"Encrypted Password  from function:{encryptedPassword}");
            return encryptedPassword;
        }
    }



}
